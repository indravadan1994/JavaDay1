/*

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arraylistexample;
import java.util.Comparator;
/**
 *
 * @author moxdroid
 */
public class MovieSort implements Comparable<Movie> {

    @Override
    public String toString() {
        return "Movie{" + "movieId=" + movieId + ", movieTitle=" + movieTitle + '}';
    }

    public MovieSort() {
    }

    public MovieSort(int movieId, String movieTitle) {
        this.movieId = movieId;
        this.movieTitle = movieTitle;
    }
    int movieId;
    String movieTitle;
 
    public int getMovieId() {
        return movieId;
    }

    public void setMovieId(int movieId) {
        this.movieId = movieId;
    }
   
    public String getMovieTitle() {
        return movieTitle;
    }

    public void setMovieTitle(String movieTitle) {
        this.movieTitle = movieTitle;
    }

    
    
    public static Comparator<MovieSort> StuNameComparator = new Comparator<MovieSort>() {

	public int compare(MovieSort s1, MovieSort s2) {
	   String StudentName1 = s1.getMovieTitle().toUpperCase();
	   String StudentName2 = s2.getMovieTitle().toLowerCase();

	   //ascending order
	   return s1.compareTo(s2);

	   //descending order
	   //return StudentName2.compareTo(StudentName1);
    }

       

       
    };

    /*Comparator for sorting the list by roll no*/
    public static Comparator<MovieSort> StuRollno = new Comparator<MovieSort>() {

	public int compare(MovieSort s1, MovieSort s2) {

	   int rollno1 = s1.getMovieId();
	   int rollno2 = s2.getMovieId();

	   /*For ascending order*/
	   return rollno1-rollno2;

	   /*For descending order*/
	   //rollno2-rollno1;
   }};

    private int compareTo(MovieSort s2) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int compareTo(Movie o) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    

   
    
}
